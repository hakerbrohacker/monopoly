/*
  # Fix Asset Policies

  1. Changes
    - Drop all existing asset policies
    - Create new simplified policies for assets
    - Enable public read access for available assets
    - Allow authenticated users full access to their own assets
    - Grant admin users full access
  
  2. Security
    - Enable RLS for assets table
    - Add comprehensive policies for all CRUD operations
*/

-- First ensure RLS is enabled
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;

-- Drop all existing asset policies to start fresh
DROP POLICY IF EXISTS "View all assets" ON assets;
DROP POLICY IF EXISTS "Create assets" ON assets;
DROP POLICY IF EXISTS "Update assets" ON assets;
DROP POLICY IF EXISTS "Delete assets" ON assets;

-- Create new simplified policies
CREATE POLICY "Public read access"
  ON assets FOR SELECT
  TO PUBLIC
  USING (status = 'Available');

CREATE POLICY "Authenticated read access"
  ON assets FOR SELECT
  TO authenticated
  USING (
    status = 'Available' OR 
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Seller create access"
  ON assets FOR INSERT
  TO authenticated
  WITH CHECK (
    seller_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND (type = 'Seller' OR is_admin = true)
    )
  );

CREATE POLICY "Owner update access"
  ON assets FOR UPDATE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Owner delete access"
  ON assets FOR DELETE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );