/*
  # Add admin account

  1. Changes
    - Creates an admin user with email admin@ecocircuit.com
    - Sets up the admin profile with admin privileges
    - Ensures the user has the correct role and permissions

  2. Security
    - Password is securely hashed
    - Admin privileges are properly set
*/

-- Create admin user if it doesn't exist
INSERT INTO auth.users (
  id,
  instance_id,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at,
  raw_app_meta_data,
  raw_user_meta_data,
  is_super_admin,
  role_id
)
VALUES (
  '11111111-1111-1111-1111-111111111111',
  '00000000-0000-0000-0000-000000000000',
  'admin@ecocircuit.com',
  crypt('admin123', gen_salt('bf')),
  now(),
  now(),
  now(),
  '{"provider": "email", "providers": ["email"]}'::jsonb,
  '{"company": "EcoCircuit Admin", "type": "Seller"}'::jsonb,
  false,
  1
)
ON CONFLICT (email) DO NOTHING;

-- Create admin profile
INSERT INTO profiles (
  id,
  company,
  type,
  location,
  is_admin,
  created_at,
  updated_at
)
VALUES (
  '11111111-1111-1111-1111-111111111111',
  'EcoCircuit Admin',
  'Seller',
  'System',
  true,
  now(),
  now()
)
ON CONFLICT (id) DO NOTHING;

-- Ensure admin stats exist
INSERT INTO seller_stats (user_id)
VALUES ('11111111-1111-1111-1111-111111111111')
ON CONFLICT (user_id) DO NOTHING;