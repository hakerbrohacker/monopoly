/*
  # Fix Admin Permissions for Assets and Profiles

  1. Changes
    - Drop and recreate all asset and profile policies
    - Ensure proper admin access to all resources
    - Maintain regular user access where appropriate
    
  2. Security
    - Admins get full access to all resources
    - Regular users retain their existing permissions
    - Proper policy hierarchy
*/

-- First drop all existing policies to start fresh
DROP POLICY IF EXISTS "Public read access for available assets" ON assets;
DROP POLICY IF EXISTS "Authenticated users can view all assets" ON assets;
DROP POLICY IF EXISTS "Sellers can create assets" ON assets;
DROP POLICY IF EXISTS "Sellers can update their own assets" ON assets;
DROP POLICY IF EXISTS "Sellers can delete their own assets" ON assets;
DROP POLICY IF EXISTS "Admin full access to assets" ON assets;
DROP POLICY IF EXISTS "Users can manage their own assets" ON assets;

DROP POLICY IF EXISTS "View profiles" ON profiles;
DROP POLICY IF EXISTS "Update profiles" ON profiles;
DROP POLICY IF EXISTS "Delete profiles" ON profiles;
DROP POLICY IF EXISTS "Admin full access to profiles" ON profiles;
DROP POLICY IF EXISTS "Users can manage their own profile" ON profiles;

-- Create new asset policies with proper hierarchy
CREATE POLICY "Asset read access"
  ON assets FOR SELECT
  TO authenticated
  USING (
    status = 'Available' OR 
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Asset write access"
  ON assets FOR INSERT
  TO authenticated
  WITH CHECK (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Asset update access"
  ON assets FOR UPDATE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Asset delete access"
  ON assets FOR DELETE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Create new profile policies with proper hierarchy
CREATE POLICY "Profile read access"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Profile write access"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Profile update access"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Profile delete access"
  ON profiles FOR DELETE
  TO authenticated
  USING (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Ensure admin user exists and has proper permissions
DO $$
BEGIN
  -- Update any existing admin user
  UPDATE profiles
  SET is_admin = true
  WHERE id IN (
    SELECT id FROM auth.users
    WHERE email = 'admin@ecocircuit.com'
  );
END $$;