/*
  # Fix Asset Policies

  1. Changes
    - Drop all existing asset policies
    - Create new simplified policies for asset access
    - Ensure both regular users and admins have proper access
  
  2. Security
    - Enable RLS for assets table
    - Add policies for read/write access
    - Ensure admin override for all operations
*/

-- First drop all existing asset policies to start fresh
DROP POLICY IF EXISTS "Asset read access" ON assets;
DROP POLICY IF EXISTS "Asset write access" ON assets;
DROP POLICY IF EXISTS "Asset update access" ON assets;
DROP POLICY IF EXISTS "Asset delete access" ON assets;

-- Create new simplified policies
CREATE POLICY "View assets"
  ON assets FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Create assets"
  ON assets FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() 
      AND (type = 'Seller' OR is_admin = true)
    )
  );

CREATE POLICY "Modify assets"
  ON assets FOR UPDATE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Delete assets"
  ON assets FOR DELETE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );