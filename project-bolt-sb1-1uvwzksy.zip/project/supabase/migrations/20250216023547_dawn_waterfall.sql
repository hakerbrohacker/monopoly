/*
  # Add Admin Support and Enhanced Profiles

  1. Changes
    - Add admin flag to profiles
    - Add more profile fields
    - Add stats tables for different user types
    - Add admin policies

  2. Security
    - Maintain existing RLS policies
    - Add admin-specific policies
*/

-- Add admin column to profiles
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS avatar_url text DEFAULT '',
ADD COLUMN IF NOT EXISTS bio text DEFAULT '',
ADD COLUMN IF NOT EXISTS website text DEFAULT '',
ADD COLUMN IF NOT EXISTS social_links jsonb DEFAULT '{}';

-- Create seller stats table
CREATE TABLE IF NOT EXISTS public.seller_stats (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  total_listings int DEFAULT 0,
  active_listings int DEFAULT 0,
  total_sales numeric DEFAULT 0,
  avg_rating numeric DEFAULT 0,
  total_reviews int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create recycler stats table
CREATE TABLE IF NOT EXISTS public.recycler_stats (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  total_recycled int DEFAULT 0,
  co2_saved numeric DEFAULT 0,
  materials_processed numeric DEFAULT 0,
  certifications jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create refurbisher stats table
CREATE TABLE IF NOT EXISTS public.refurbisher_stats (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  items_refurbished int DEFAULT 0,
  success_rate numeric DEFAULT 0,
  specializations jsonb DEFAULT '[]',
  warranty_claims int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE seller_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE recycler_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE refurbisher_stats ENABLE ROW LEVEL SECURITY;

-- Create policies for stats tables
CREATE POLICY "Users can view their own stats"
  ON seller_stats FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Users can view their own stats"
  ON recycler_stats FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Users can view their own stats"
  ON refurbisher_stats FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true));

-- Create admin user if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE email = 'admin@ecocircuit.com'
  ) THEN
    -- Note: This is just for demo purposes. In production, use a secure password
    INSERT INTO auth.users (
      email,
      encrypted_password,
      email_confirmed_at,
      raw_user_meta_data
    ) VALUES (
      'admin@ecocircuit.com',
      crypt('admin123', gen_salt('bf')),
      now(),
      '{"company": "EcoCircuit", "type": "Admin", "is_admin": true}'
    );
  END IF;
END $$;