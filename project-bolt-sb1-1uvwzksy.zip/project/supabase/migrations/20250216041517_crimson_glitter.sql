/*
  # Fix assets loading and policies

  1. Changes
    - Drop and recreate assets table policies
    - Add policy for public read access to available assets
    - Add policy for sellers to manage their assets
    - Add policy for authenticated users to view assets

  2. Security
    - Enable RLS on assets table
    - Add appropriate policies for different user roles
*/

-- First ensure RLS is enabled
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view available assets" ON assets;
DROP POLICY IF EXISTS "Sellers can create assets" ON assets;
DROP POLICY IF EXISTS "Sellers can update their own assets" ON assets;

-- Create new policies
CREATE POLICY "Public read access for available assets"
  ON assets FOR SELECT
  USING (status = 'Available');

CREATE POLICY "Authenticated users can view all assets"
  ON assets FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Sellers can create assets"
  ON assets FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND type = 'Seller'
    )
  );

CREATE POLICY "Sellers can update their own assets"
  ON assets FOR UPDATE
  TO authenticated
  USING (seller_id = auth.uid())
  WITH CHECK (seller_id = auth.uid());

CREATE POLICY "Sellers can delete their own assets"
  ON assets FOR DELETE
  TO authenticated
  USING (seller_id = auth.uid());