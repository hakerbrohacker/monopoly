/*
  # Seed initial assets

  1. New Data
    - Add sample assets to the assets table
    - Include various types of IT equipment
    - Add realistic specifications and certifications
*/

-- First, ensure we have a seller account to associate the assets with
DO $$ 
DECLARE
  seller_id uuid;
BEGIN
  -- Insert a demo seller if none exists
  INSERT INTO auth.users (id, email)
  VALUES (
    '00000000-0000-0000-0000-000000000000',
    'demo.seller@example.com'
  )
  ON CONFLICT (id) DO NOTHING;

  -- Ensure the seller has a profile
  INSERT INTO profiles (id, company, type, location)
  VALUES (
    '00000000-0000-0000-0000-000000000000',
    'Demo Tech Solutions',
    'Seller',
    'New York, NY'
  )
  ON CONFLICT (id) DO NOTHING;

  -- Store the seller_id for use in assets
  seller_id := '00000000-0000-0000-0000-000000000000';

  -- Insert sample assets
  INSERT INTO assets (
    name,
    category,
    condition,
    quantity,
    location,
    description,
    specifications,
    certifications,
    price,
    images,
    status,
    seller_id
  ) VALUES 
  (
    'Dell PowerEdge R740 Server',
    'Servers',
    'Used',
    1,
    'New York, NY',
    'Enterprise-grade server with dual Intel Xeon processors, 64GB RAM, and redundant power supplies.',
    '{"processor": "Intel Xeon Gold 5218", "ram": "64GB DDR4", "storage": "2x 480GB SSD"}'::jsonb,
    ARRAY['R2', 'ISO 14001'],
    2499,
    ARRAY['https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800'],
    'Available',
    seller_id
  ),
  (
    'Cisco Catalyst 9300 Switch',
    'Networking',
    'Like New',
    1,
    'San Francisco, CA',
    'Enterprise-class access switching platform built for security, IoT, mobility, and cloud.',
    '{"ports": "48x 1G", "uplinks": "4x 10G", "power": "PoE+"}'::jsonb,
    ARRAY['ISO 14001'],
    1899,
    ARRAY['https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800'],
    'Available',
    seller_id
  ),
  (
    'HP EliteBook 850 G8',
    'Computers',
    'New',
    5,
    'Austin, TX',
    'Business laptop with Intel Core i7, 16GB RAM, and 512GB SSD.',
    '{"processor": "Intel Core i7-1165G7", "ram": "16GB DDR4", "storage": "512GB NVMe SSD"}'::jsonb,
    ARRAY['Energy Star', 'EPEAT Gold'],
    899,
    ARRAY['https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800'],
    'Available',
    seller_id
  ),
  (
    'Lenovo ThinkCentre M720',
    'Computers',
    'Refurbished',
    10,
    'Chicago, IL',
    'Compact business desktop PC, perfect for office use.',
    '{"processor": "Intel Core i5-9400", "ram": "8GB DDR4", "storage": "256GB SSD"}'::jsonb,
    ARRAY['Energy Star'],
    449,
    ARRAY['https://images.unsplash.com/photo-1587831990711-23ca6441447b?w=800'],
    'Available',
    seller_id
  ),
  (
    'Juniper EX4300 Switch',
    'Networking',
    'Used',
    2,
    'Miami, FL',
    'High-performance access switch with advanced security features.',
    '{"ports": "48x 1G", "uplinks": "4x 10G", "power": "Redundant PSU"}'::jsonb,
    ARRAY['R2'],
    1299,
    ARRAY['https://images.unsplash.com/photo-1551703599-6b3e8379aa8b?w=800'],
    'Available',
    seller_id
  ),
  (
    'Apple iMac 27" (2020)',
    'Computers',
    'Like New',
    1,
    'Seattle, WA',
    '5K Retina display, Intel Core i7, perfect for creative professionals.',
    '{"processor": "Intel Core i7", "ram": "32GB DDR4", "storage": "1TB SSD"}'::jsonb,
    ARRAY['Energy Star'],
    1599,
    ARRAY['https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=800'],
    'Available',
    seller_id
  );
END $$;