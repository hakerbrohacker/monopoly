/*
  # Create admin user and profile

  1. Changes
    - Creates an admin user in auth.users
    - Sets up the admin profile with admin privileges
    - Ensures proper stats records exist

  2. Security
    - Password is securely hashed
    - Admin privileges are properly set
*/

-- Create admin user if it doesn't exist
INSERT INTO auth.users (
  id,
  instance_id,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at,
  raw_app_meta_data,
  raw_user_meta_data
)
SELECT
  '11111111-1111-1111-1111-111111111111',
  '00000000-0000-0000-0000-000000000000',
  'admin@ecocircuit.com',
  crypt('admin123', gen_salt('bf')),
  now(),
  now(),
  now(),
  '{"provider": "email", "providers": ["email"]}'::jsonb,
  '{"company": "EcoCircuit Admin", "type": "Seller"}'::jsonb
WHERE NOT EXISTS (
  SELECT 1 FROM auth.users WHERE id = '11111111-1111-1111-1111-111111111111'
);

-- Create admin profile
INSERT INTO public.profiles (
  id,
  company,
  type,
  location,
  is_admin,
  created_at,
  updated_at
)
SELECT
  '11111111-1111-1111-1111-111111111111',
  'EcoCircuit Admin',
  'Seller',
  'System',
  true,
  now(),
  now()
WHERE NOT EXISTS (
  SELECT 1 FROM public.profiles WHERE id = '11111111-1111-1111-1111-111111111111'
);

-- Ensure admin stats exist
INSERT INTO public.seller_stats (user_id)
SELECT '11111111-1111-1111-1111-111111111111'
WHERE NOT EXISTS (
  SELECT 1 FROM public.seller_stats WHERE user_id = '11111111-1111-1111-1111-111111111111'
);