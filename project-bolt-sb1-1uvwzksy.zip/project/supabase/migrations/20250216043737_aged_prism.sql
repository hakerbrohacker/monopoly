/*
  # Fix Asset Policies

  1. Changes
    - Drop all existing asset policies
    - Create new simplified policies with proper access control
    - Ensure both admins and sellers can manage assets
    - Allow all authenticated users to view assets
  
  2. Security
    - Enable RLS for assets table
    - Add comprehensive policies for all CRUD operations
    - Ensure proper access control for admins and sellers
*/

-- First ensure RLS is enabled
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;

-- Drop all existing asset policies to start fresh
DROP POLICY IF EXISTS "View assets" ON assets;
DROP POLICY IF EXISTS "Create assets" ON assets;
DROP POLICY IF EXISTS "Modify assets" ON assets;
DROP POLICY IF EXISTS "Delete assets" ON assets;

-- Create new simplified policies
CREATE POLICY "View all assets"
  ON assets FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Create assets"
  ON assets FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() 
      AND (type = 'Seller' OR is_admin = true)
    )
  );

CREATE POLICY "Update assets"
  ON assets FOR UPDATE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Delete assets"
  ON assets FOR DELETE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Verify admin exists and has proper permissions
DO $$
BEGIN
  UPDATE profiles
  SET is_admin = true
  WHERE id IN (
    SELECT id FROM auth.users
    WHERE email = 'admin@ecocircuit.com'
  );
END $$;