/*
  # Fix Admin Permissions

  1. Changes
    - Drop existing policies that may conflict
    - Create new comprehensive admin policies for all operations
    - Ensure proper access control hierarchy
    
  2. Security
    - Admins get full access to all resources
    - Regular users retain their existing permissions
    - Maintains proper security boundaries
*/

-- First drop any existing policies that might conflict
DROP POLICY IF EXISTS "Admin full access to assets" ON assets;
DROP POLICY IF EXISTS "Admin full access to profiles" ON profiles;
DROP POLICY IF EXISTS "Users can manage their own assets" ON assets;
DROP POLICY IF EXISTS "Users can manage their own profile" ON profiles;
DROP POLICY IF EXISTS "Anyone can view available assets" ON assets;
DROP POLICY IF EXISTS "Sellers can create assets" ON assets;
DROP POLICY IF EXISTS "Sellers can update their own assets" ON assets;

-- Create comprehensive admin policies
CREATE POLICY "Admin full access to assets"
  ON assets
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Admin full access to profiles"
  ON profiles
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Recreate regular user policies
CREATE POLICY "Anyone can view available assets"
  ON assets
  FOR SELECT
  TO authenticated
  USING (
    status = 'Available' OR 
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Users can manage their own assets"
  ON assets
  FOR ALL
  TO authenticated
  USING (seller_id = auth.uid())
  WITH CHECK (seller_id = auth.uid());

CREATE POLICY "Users can manage their own profile"
  ON profiles
  FOR ALL
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- Ensure proper access to stats tables
CREATE POLICY "Admin full access to seller stats"
  ON seller_stats
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Admin full access to recycler stats"
  ON recycler_stats
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Admin full access to refurbisher stats"
  ON refurbisher_stats
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );