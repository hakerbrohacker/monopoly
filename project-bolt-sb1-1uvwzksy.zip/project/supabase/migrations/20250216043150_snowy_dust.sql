/*
  # Add admin management capabilities
  
  1. Changes
    - Add admin policies for managing assets and profiles
    - Allow admins to update and delete any asset
    - Allow admins to update and delete any profile
  
  2. Security
    - Ensure proper RLS policies for admin access
    - Maintain existing user permissions
*/

-- Drop existing asset policies
DROP POLICY IF EXISTS "Sellers can update their own assets" ON assets;
DROP POLICY IF EXISTS "Sellers can delete their own assets" ON assets;

-- Create new asset management policies for admins
CREATE POLICY "Admins can update any asset"
  ON assets FOR UPDATE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Admins can delete any asset"
  ON assets FOR DELETE
  TO authenticated
  USING (
    seller_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Add admin policies for profile management
CREATE POLICY "Admins can update any profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Admins can delete any profile"
  ON profiles FOR DELETE
  TO authenticated
  USING (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );