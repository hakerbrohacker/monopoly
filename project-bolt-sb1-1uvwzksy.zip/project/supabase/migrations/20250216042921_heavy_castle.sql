/*
  # Create admin profile

  1. Changes
    - Creates admin profile with admin privileges
    - Ensures proper stats records exist
    - Updates existing user to have admin privileges if they exist

  2. Security
    - Admin privileges are properly set
*/

-- Create admin profile if it doesn't exist
INSERT INTO public.profiles (
  id,
  company,
  type,
  location,
  is_admin,
  created_at,
  updated_at
)
SELECT
  auth.uid(),
  'EcoCircuit Admin',
  'Seller',
  'System',
  true,
  now(),
  now()
FROM auth.users
WHERE email = 'admin@ecocircuit.com'
AND NOT EXISTS (
  SELECT 1 FROM public.profiles 
  WHERE id = auth.users.id
);

-- Ensure admin stats exist
INSERT INTO public.seller_stats (user_id)
SELECT p.id
FROM public.profiles p
WHERE p.is_admin = true
AND NOT EXISTS (
  SELECT 1 FROM public.seller_stats 
  WHERE user_id = p.id
);

-- Update any existing user with admin@ecocircuit.com to be an admin
UPDATE public.profiles
SET is_admin = true
WHERE id IN (
  SELECT id FROM auth.users
  WHERE email = 'admin@ecocircuit.com'
);