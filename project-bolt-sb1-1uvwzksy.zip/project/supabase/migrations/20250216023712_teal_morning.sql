/*
  # Add Admin Support and Enhanced Profiles

  1. Changes
    - Add admin flag and additional fields to profiles
    - Create stats tables for different user types
    - Add RLS policies for stats tables

  2. Security
    - Enable RLS on all new tables
    - Add policies for viewing stats
*/

-- Add new columns to profiles
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS avatar_url text DEFAULT '',
ADD COLUMN IF NOT EXISTS bio text DEFAULT '',
ADD COLUMN IF NOT EXISTS website text DEFAULT '',
ADD COLUMN IF NOT EXISTS social_links jsonb DEFAULT '{}';

-- Create seller stats table
CREATE TABLE IF NOT EXISTS public.seller_stats (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  total_listings int DEFAULT 0,
  active_listings int DEFAULT 0,
  total_sales numeric DEFAULT 0,
  avg_rating numeric DEFAULT 0,
  total_reviews int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create recycler stats table
CREATE TABLE IF NOT EXISTS public.recycler_stats (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  total_recycled int DEFAULT 0,
  co2_saved numeric DEFAULT 0,
  materials_processed numeric DEFAULT 0,
  certifications jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create refurbisher stats table
CREATE TABLE IF NOT EXISTS public.refurbisher_stats (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  items_refurbished int DEFAULT 0,
  success_rate numeric DEFAULT 0,
  specializations jsonb DEFAULT '[]',
  warranty_claims int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE seller_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE recycler_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE refurbisher_stats ENABLE ROW LEVEL SECURITY;

-- Create policies for stats tables
CREATE POLICY "Users can view their own stats"
  ON seller_stats FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Users can view their own stats"
  ON recycler_stats FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Users can view their own stats"
  ON refurbisher_stats FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true));

-- Add policy for admin access to profiles
CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    auth.uid() = id OR 
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Update existing profiles policy
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
CREATE POLICY "Users can view their own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Function to update user type stats
CREATE OR REPLACE FUNCTION create_user_stats()
RETURNS trigger AS $$
BEGIN
  IF NEW.type = 'Seller' THEN
    INSERT INTO seller_stats (user_id) VALUES (NEW.id)
    ON CONFLICT (user_id) DO NOTHING;
  ELSIF NEW.type = 'Recycler' THEN
    INSERT INTO recycler_stats (user_id) VALUES (NEW.id)
    ON CONFLICT (user_id) DO NOTHING;
  ELSIF NEW.type = 'Refurbisher' THEN
    INSERT INTO refurbisher_stats (user_id) VALUES (NEW.id)
    ON CONFLICT (user_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for stats creation
DROP TRIGGER IF EXISTS on_profile_created ON profiles;
CREATE TRIGGER on_profile_created
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION create_user_stats();