/*
  # Fix User Stats Tables and Policies

  1. Changes
    - Improve stats table initialization
    - Fix stats retrieval policies
    - Add proper error handling for stats creation

  2. Security
    - Maintain RLS policies
    - Ensure proper access control
*/

-- Drop existing trigger first to avoid conflicts
DROP TRIGGER IF EXISTS on_profile_created ON profiles;
DROP FUNCTION IF EXISTS create_user_stats();

-- Improve create_user_stats function with better error handling
CREATE OR REPLACE FUNCTION create_user_stats()
RETURNS trigger AS $$
BEGIN
  -- Create stats based on user type
  CASE NEW.type
    WHEN 'Seller' THEN
      INSERT INTO seller_stats (user_id)
      VALUES (NEW.id)
      ON CONFLICT (user_id) DO NOTHING;
      
    WHEN 'Recycler' THEN
      INSERT INTO recycler_stats (user_id)
      VALUES (NEW.id)
      ON CONFLICT (user_id) DO NOTHING;
      
    WHEN 'Refurbisher' THEN
      INSERT INTO refurbisher_stats (user_id)
      VALUES (NEW.id)
      ON CONFLICT (user_id) DO NOTHING;
  END CASE;
  
  RETURN NEW;
EXCEPTION
  WHEN others THEN
    RAISE LOG 'Error in create_user_stats: %', SQLERRM;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate trigger for stats creation
CREATE TRIGGER on_profile_created
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION create_user_stats();

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view their own stats" ON seller_stats;
DROP POLICY IF EXISTS "Users can view their own stats" ON recycler_stats;
DROP POLICY IF EXISTS "Users can view their own stats" ON refurbisher_stats;

-- Create new policies with better access control
CREATE POLICY "View seller stats"
  ON seller_stats FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "View recycler stats"
  ON recycler_stats FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "View refurbisher stats"
  ON refurbisher_stats FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Ensure stats exist for all current users
DO $$
DECLARE
  profile_record RECORD;
BEGIN
  FOR profile_record IN SELECT * FROM profiles LOOP
    CASE profile_record.type
      WHEN 'Seller' THEN
        INSERT INTO seller_stats (user_id)
        VALUES (profile_record.id)
        ON CONFLICT (user_id) DO NOTHING;
        
      WHEN 'Recycler' THEN
        INSERT INTO recycler_stats (user_id)
        VALUES (profile_record.id)
        ON CONFLICT (user_id) DO NOTHING;
        
      WHEN 'Refurbisher' THEN
        INSERT INTO refurbisher_stats (user_id)
        VALUES (profile_record.id)
        ON CONFLICT (user_id) DO NOTHING;
    END CASE;
  END LOOP;
END $$;