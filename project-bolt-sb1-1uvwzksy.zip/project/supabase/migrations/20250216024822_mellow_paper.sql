/*
  # Fix Profile Policies

  1. Changes
    - Remove recursive admin policies
    - Add proper admin access controls
    - Grant necessary permissions

  2. Security
    - Enable admin access to all profiles
    - Maintain user access to own profile
    - Fix infinite recursion in policies
*/

-- Create admin role if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_roles WHERE rolname = 'admin'
  ) THEN
    CREATE ROLE admin;
  END IF;
END $$;

-- Update profiles table to ensure admin access
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false;

-- Drop existing policies to clean up
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
DROP POLICY IF EXISTS "Admins can update any profile" ON profiles;
DROP POLICY IF EXISTS "Admins can delete any profile" ON profiles;

-- Create new, optimized policies
CREATE POLICY "View profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR 
    is_admin = true
  );

CREATE POLICY "Update profiles"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    id = auth.uid() OR 
    is_admin = true
  )
  WITH CHECK (
    id = auth.uid() OR 
    is_admin = true
  );

CREATE POLICY "Delete profiles"
  ON profiles FOR DELETE
  TO authenticated
  USING (
    id = auth.uid() OR 
    is_admin = true
  );

-- Grant necessary permissions to admin role
GRANT ALL ON ALL TABLES IN SCHEMA public TO admin;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO admin;
GRANT ALL ON ALL FUNCTIONS IN SCHEMA public TO admin;

-- Update existing admin user if exists
DO $$
BEGIN
  UPDATE profiles
  SET is_admin = true
  WHERE id IN (
    SELECT id FROM auth.users
    WHERE email = 'admin@ecocircuit.com'
  );
END $$;