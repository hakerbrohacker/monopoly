/*
  # Initial Schema Setup

  1. New Tables
    - `profiles`
      - User profile information including company details and type
    - `assets`
      - Asset listings with detailed information
    - `transactions`
      - Transaction records between buyers and sellers

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  company text NOT NULL,
  type text NOT NULL CHECK (type IN ('Seller', 'Recycler', 'Refurbisher')),
  location text,
  rating numeric DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create assets table
CREATE TABLE IF NOT EXISTS assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  category text NOT NULL CHECK (category IN ('Computers', 'Phones', 'Servers', 'Networking', 'Other')),
  condition text NOT NULL CHECK (condition IN ('New', 'Like New', 'Used', 'For Parts')),
  quantity integer NOT NULL CHECK (quantity > 0),
  location text NOT NULL,
  description text NOT NULL,
  specifications jsonb DEFAULT '{}'::jsonb,
  certifications text[] DEFAULT ARRAY[]::text[],
  price numeric NOT NULL CHECK (price >= 0),
  images text[] DEFAULT ARRAY[]::text[],
  status text NOT NULL CHECK (status IN ('Available', 'Pending', 'Sold', 'In Transit')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id uuid REFERENCES assets(id) ON DELETE SET NULL,
  seller_id uuid REFERENCES profiles(id),
  buyer_id uuid REFERENCES profiles(id),
  price numeric NOT NULL CHECK (price >= 0),
  status text NOT NULL CHECK (status IN ('Pending', 'Confirmed', 'In Transit', 'Completed')),
  tracking_info jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Assets policies
CREATE POLICY "Anyone can view available assets"
  ON assets FOR SELECT
  TO authenticated
  USING (status = 'Available' OR seller_id = auth.uid());

CREATE POLICY "Sellers can create assets"
  ON assets FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND type = 'Seller'
    )
  );

CREATE POLICY "Sellers can update their own assets"
  ON assets FOR UPDATE
  TO authenticated
  USING (seller_id = auth.uid());

-- Transactions policies
CREATE POLICY "Users can view their own transactions"
  ON transactions FOR SELECT
  TO authenticated
  USING (seller_id = auth.uid() OR buyer_id = auth.uid());

CREATE POLICY "Users can create transactions"
  ON transactions FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles WHERE id = auth.uid()
    )
  );

-- Create function to handle user profile creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO profiles (id, company, type)
  VALUES (
    new.id,
    new.raw_user_meta_data->>'company',
    new.raw_user_meta_data->>'type'
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user profile creation
CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();