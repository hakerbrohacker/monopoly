import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import AssetCard from './components/AssetCard';
import TrackingDashboard from './components/TrackingDashboard';
import Analytics from './components/Analytics';
import UserProfile from './components/UserProfile';
import CreateAssetModal from './components/CreateAssetModal';
import { supabase } from './lib/supabase';
import { Asset } from './types';
import { Plus } from 'lucide-react';
import toast from 'react-hot-toast';

function App() {
  const [activeTab, setActiveTab] = useState<'marketplace' | 'tracking' | 'analytics' | 'profile'>('marketplace');
  const [selectedCategory, setSelectedCategory] = useState<string>('All Categories');
  const [selectedCondition, setSelectedCondition] = useState<string>('All Conditions');
  const [showCreateAsset, setShowCreateAsset] = useState(false);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [userType, setUserType] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAssets();
    checkUserType();
  }, []);

  const loadAssets = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('assets')
        .select(`
          id,
          name,
          category,
          condition,
          quantity,
          location,
          description,
          specifications,
          certifications,
          price,
          images,
          status,
          seller_id,
          created_at
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const transformedAssets = data.map(asset => ({
        ...asset,
        sellerId: asset.seller_id,
        createdAt: new Date(asset.created_at),
        specifications: asset.specifications || {},
        certifications: asset.certifications || [],
        images: asset.images || [],
      }));

      setAssets(transformedAssets);
    } catch (error: any) {
      toast.error('Error loading assets: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const checkUserType = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('type, is_admin')
          .eq('id', user.id)
          .single();
        
        if (error) throw error;
        setUserType(profile?.type || null);
        setIsAdmin(profile?.is_admin || false);
      }
    } catch (error: any) {
      console.error('Error checking user type:', error);
    }
  };

  const handleAssetCreated = (newAsset: Asset) => {
    setAssets([newAsset, ...assets]);
  };

  const handleAssetDeleted = (assetId: string) => {
    setAssets(assets.filter(a => a.id !== assetId));
  };

  const filteredAssets = assets.filter(asset => {
    if (selectedCategory !== 'All Categories' && asset.category !== selectedCategory) return false;
    if (selectedCondition !== 'All Conditions' && asset.condition !== selectedCondition) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'marketplace' && (
          <>
            <Dashboard />
            <div className="mt-8">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 space-y-4 sm:space-y-0">
                <h2 className="text-3xl font-bold text-gray-900">Featured Assets</h2>
                <div className="flex flex-col sm:flex-row gap-4">
                  {(userType === 'Seller' || isAdmin) && (
                    <button
                      onClick={() => setShowCreateAsset(true)}
                      className="flex items-center space-x-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors shadow-sm"
                    >
                      <Plus className="h-5 w-5" />
                      <span>Create Asset</span>
                    </button>
                  )}
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  >
                    <option>All Categories</option>
                    <option>Computers</option>
                    <option>Servers</option>
                    <option>Networking</option>
                  </select>
                  <select
                    value={selectedCondition}
                    onChange={(e) => setSelectedCondition(e.target.value)}
                    className="bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  >
                    <option>All Conditions</option>
                    <option>New</option>
                    <option>Like New</option>
                    <option>Used</option>
                    <option>For Parts</option>
                  </select>
                </div>
              </div>
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
                </div>
              ) : filteredAssets.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {filteredAssets.map((asset) => (
                    <AssetCard 
                      key={asset.id} 
                      asset={asset} 
                      isAdmin={isAdmin}
                      onDelete={() => handleAssetDeleted(asset.id)}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500 text-lg">No assets found matching your criteria.</p>
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === 'tracking' && <TrackingDashboard />}
        {activeTab === 'analytics' && <Analytics />}
        {activeTab === 'profile' && <UserProfile />}
      </main>

      <CreateAssetModal
        isOpen={showCreateAsset}
        onClose={() => setShowCreateAsset(false)}
        onAssetCreated={handleAssetCreated}
      />
    </div>
  );
}

export default App;