import React, { useState } from 'react';
import { X, Upload } from 'lucide-react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { Asset } from '../types';

interface CreateDealModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDealCreated: (newAsset: Asset) => void;
}

export default function CreateDealModal({ isOpen, onClose, onDealCreated }: CreateDealModalProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: 'Computers' as Asset['category'],
    condition: 'New' as Asset['condition'],
    quantity: 1,
    location: '',
    description: '',
    price: 0,
    specifications: {
      processor: '',
      memory: '',
      storage: ''
    },
    certifications: [] as string[],
    images: [''] as string[],
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Verify user is a seller
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('type')
        .eq('id', user.id)
        .single();

      if (profileError) throw profileError;
      if (profile.type !== 'Seller') {
        throw new Error('Only sellers can create deals');
      }

      const newAsset = {
        ...formData,
        seller_id: user.id,
        status: 'Available',
      };

      const { data, error } = await supabase
        .from('assets')
        .insert([newAsset])
        .select()
        .single();

      if (error) throw error;

      toast.success('Deal created successfully!');
      onDealCreated(data);
      onClose();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X className="h-6 w-6" />
        </button>
        
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2 bg-emerald-100 rounded-lg">
            <Upload className="h-6 w-6 text-emerald-600" />
          </div>
          <h2 className="text-2xl font-bold">Create New Deal</h2>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Asset Name
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                placeholder="e.g., Dell PowerEdge R740 Server"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Category
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value as Asset['category'] })}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              >
                <option value="Computers">Computers</option>
                <option value="Servers">Servers</option>
                <option value="Networking">Networking</option>
                <option value="Phones">Phones</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Condition
              </label>
              <select
                value={formData.condition}
                onChange={(e) => setFormData({ ...formData, condition: e.target.value as Asset['condition'] })}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              >
                <option value="New">New</option>
                <option value="Like New">Like New</option>
                <option value="Used">Used</option>
                <option value="For Parts">For Parts</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Quantity
              </label>
              <input
                type="number"
                min="1"
                required
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) })}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Location
              </label>
              <input
                type="text"
                required
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                placeholder="e.g., New York, NY"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Price (USD)
              </label>
              <input
                type="number"
                min="0"
                step="0.01"
                required
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              required
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              placeholder="Detailed description of the asset..."
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Processor
              </label>
              <input
                type="text"
                value={formData.specifications.processor}
                onChange={(e) => setFormData({
                  ...formData,
                  specifications: {
                    ...formData.specifications,
                    processor: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                placeholder="e.g., Intel Core i7"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Memory
              </label>
              <input
                type="text"
                value={formData.specifications.memory}
                onChange={(e) => setFormData({
                  ...formData,
                  specifications: {
                    ...formData.specifications,
                    memory: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                placeholder="e.g., 16GB DDR4"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Storage
              </label>
              <input
                type="text"
                value={formData.specifications.storage}
                onChange={(e) => setFormData({
                  ...formData,
                  specifications: {
                    ...formData.specifications,
                    storage: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                placeholder="e.g., 512GB SSD"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Certifications (comma-separated)
            </label>
            <input
              type="text"
              value={formData.certifications.join(', ')}
              onChange={(e) => setFormData({
                ...formData,
                certifications: e.target.value.split(',').map(cert => cert.trim()).filter(Boolean)
              })}
              className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              placeholder="e.g., R2, ISO 14001, Energy Star"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Image URL
            </label>
            <input
              type="url"
              value={formData.images[0]}
              onChange={(e) => setFormData({ ...formData, images: [e.target.value] })}
              placeholder="https://example.com/image.jpg"
              className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-600 text-white py-3 px-4 rounded-lg hover:bg-emerald-700 disabled:opacity-50 transition-colors font-medium"
          >
            {loading ? 'Creating...' : 'Create Deal'}
          </button>
        </form>
      </div>
    </div>
  );
}