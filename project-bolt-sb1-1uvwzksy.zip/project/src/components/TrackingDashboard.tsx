import React from 'react';
import { Package, MapPin, Calendar, Clock } from 'lucide-react';

interface ShipmentStatus {
  id: string;
  assetName: string;
  origin: string;
  destination: string;
  status: 'In Transit' | 'Delivered' | 'Processing' | 'Delayed';
  estimatedDelivery: string;
  lastUpdate: string;
  carrier: string;
  trackingNumber: string;
}

const sampleShipments: ShipmentStatus[] = [
  {
    id: '1',
    assetName: 'Dell Server Rack',
    origin: 'New York, NY',
    destination: 'Chicago, IL',
    status: 'In Transit',
    estimatedDelivery: '2025-03-15',
    lastUpdate: '2 hours ago',
    carrier: 'FedEx',
    trackingNumber: 'FX1234567890'
  },
  {
    id: '2',
    assetName: 'Network Switch Bundle',
    origin: 'San Francisco, CA',
    destination: 'Austin, TX',
    status: 'Processing',
    estimatedDelivery: '2025-03-18',
    lastUpdate: '1 hour ago',
    carrier: 'UPS',
    trackingNumber: 'UP9876543210'
  }
];

export default function TrackingDashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Asset Tracking</h2>
        <div className="space-y-6">
          {sampleShipments.map((shipment) => (
            <div key={shipment.id} className="border rounded-lg p-4">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold">{shipment.assetName}</h3>
                  <p className="text-sm text-gray-500">Tracking: {shipment.trackingNumber}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium
                  ${shipment.status === 'In Transit' ? 'bg-blue-100 text-blue-800' :
                    shipment.status === 'Delivered' ? 'bg-green-100 text-green-800' :
                    shipment.status === 'Processing' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'}`}>
                  {shipment.status}
                </span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-gray-400 mr-2" />
                  <div>
                    <p className="text-sm font-medium">Origin</p>
                    <p className="text-sm text-gray-500">{shipment.origin}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Package className="h-5 w-5 text-gray-400 mr-2" />
                  <div>
                    <p className="text-sm font-medium">Destination</p>
                    <p className="text-sm text-gray-500">{shipment.destination}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-gray-400 mr-2" />
                  <div>
                    <p className="text-sm font-medium">Est. Delivery</p>
                    <p className="text-sm text-gray-500">{shipment.estimatedDelivery}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-gray-400 mr-2" />
                  <div>
                    <p className="text-sm font-medium">Last Update</p>
                    <p className="text-sm text-gray-500">{shipment.lastUpdate}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}