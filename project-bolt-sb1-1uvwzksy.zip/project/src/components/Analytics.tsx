import React from 'react';
import { PieChart, LineChart, ArrowUpRight, ArrowDownRight } from 'lucide-react';

export default function Analytics() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Asset Distribution</h2>
          <div className="space-y-4">
            {[
              { category: 'Servers', percentage: 35, count: 245, trend: 'up' },
              { category: 'Networking', percentage: 28, count: 196, trend: 'up' },
              { category: 'Computers', percentage: 22, count: 154, trend: 'down' },
              { category: 'Other', percentage: 15, count: 105, trend: 'up' }
            ].map((item) => (
              <div key={item.category} className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-gray-700">{item.category}</span>
                    <span className="text-sm text-gray-500">{item.count} items</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-emerald-600 h-2 rounded-full"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
                <div className="ml-4">
                  {item.trend === 'up' ? (
                    <ArrowUpRight className="h-5 w-5 text-emerald-500" />
                  ) : (
                    <ArrowDownRight className="h-5 w-5 text-red-500" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Environmental Impact</h2>
          <div className="grid grid-cols-2 gap-6">
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="p-2 bg-emerald-100 rounded-lg">
                  <PieChart className="h-6 w-6 text-emerald-600" />
                </div>
                <span className="text-emerald-600 font-medium">+24.5%</span>
              </div>
              <h3 className="text-2xl font-bold">847</h3>
              <p className="text-sm text-gray-500">Assets Recycled</p>
            </div>
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <LineChart className="h-6 w-6 text-blue-600" />
                </div>
                <span className="text-blue-600 font-medium">+18.2%</span>
              </div>
              <h3 className="text-2xl font-bold">128.4t</h3>
              <p className="text-sm text-gray-500">CO2 Prevented</p>
            </div>
          </div>
          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-4">Top Certifications</h3>
            <div className="space-y-3">
              {[
                { name: 'R2', count: 324, percentage: 85 },
                { name: 'e-Stewards', count: 256, percentage: 70 },
                { name: 'ISO 14001', count: 198, percentage: 55 }
              ].map((cert) => (
                <div key={cert.name}>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">{cert.name}</span>
                    <span className="text-sm text-gray-500">{cert.count}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${cert.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}