import React, { useState } from 'react';
import { Menu, Bell, User, LogOut, BarChart2, Package, LineChart } from 'lucide-react';
import { supabase } from '../lib/supabase';
import AuthModal from './AuthModal';
import toast from 'react-hot-toast';

interface NavbarProps {
  activeTab: 'marketplace' | 'tracking' | 'analytics' | 'profile';
  setActiveTab: (tab: 'marketplace' | 'tracking' | 'analytics' | 'profile') => void;
}

export default function Navbar({ activeTab, setActiveTab }: NavbarProps) {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [user, setUser] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  React.useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success('Logged out successfully');
  };

  return (
    <>
      <nav className="bg-gradient-to-r from-emerald-700 to-emerald-900 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold tracking-tight">EcoCircuit</h1>
                <p className="text-xs text-emerald-200">Sustainable Tech Marketplace</p>
              </div>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => setActiveTab('marketplace')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  activeTab === 'marketplace' 
                    ? 'bg-emerald-600 text-white' 
                    : 'text-emerald-100 hover:bg-emerald-600/50'
                }`}
              >
                <Package className="h-5 w-5" />
                <span>Marketplace</span>
              </button>
              
              <button 
                onClick={() => setActiveTab('tracking')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  activeTab === 'tracking' 
                    ? 'bg-emerald-600 text-white' 
                    : 'text-emerald-100 hover:bg-emerald-600/50'
                }`}
              >
                <BarChart2 className="h-5 w-5" />
                <span>Track Assets</span>
              </button>
              
              <button 
                onClick={() => setActiveTab('analytics')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  activeTab === 'analytics' 
                    ? 'bg-emerald-600 text-white' 
                    : 'text-emerald-100 hover:bg-emerald-600/50'
                }`}
              >
                <LineChart className="h-5 w-5" />
                <span>Analytics</span>
              </button>

              {user ? (
                <div className="flex items-center space-x-4">
                  <button className="p-2 rounded-lg hover:bg-emerald-600/50 transition-colors">
                    <Bell className="h-5 w-5" />
                  </button>
                  <button 
                    onClick={() => setActiveTab('profile')}
                    className={`p-2 rounded-lg transition-colors ${
                      activeTab === 'profile'
                        ? 'bg-emerald-600'
                        : 'hover:bg-emerald-600/50'
                    }`}
                  >
                    <User className="h-5 w-5" />
                  </button>
                  <button
                    onClick={handleLogout}
                    className="p-2 rounded-lg hover:bg-emerald-600/50 transition-colors"
                  >
                    <LogOut className="h-5 w-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="bg-white text-emerald-700 px-6 py-2 rounded-lg text-sm font-medium hover:bg-emerald-50 transition-colors shadow-sm"
                >
                  Login / Sign Up
                </button>
              )}
            </div>

            <div className="md:hidden">
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-md hover:bg-emerald-600/50 transition-colors"
              >
                <Menu className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-emerald-800 shadow-lg">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button
                onClick={() => {
                  setActiveTab('marketplace');
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 rounded-md text-base font-medium text-white hover:bg-emerald-600/50 transition-colors"
              >
                Marketplace
              </button>
              <button
                onClick={() => {
                  setActiveTab('tracking');
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 rounded-md text-base font-medium text-white hover:bg-emerald-600/50 transition-colors"
              >
                Track Assets
              </button>
              <button
                onClick={() => {
                  setActiveTab('analytics');
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 rounded-md text-base font-medium text-white hover:bg-emerald-600/50 transition-colors"
              >
                Analytics
              </button>
              {user ? (
                <div className="flex items-center space-x-4 px-3 py-2">
                  <button className="p-2 rounded-lg hover:bg-emerald-600/50 transition-colors">
                    <Bell className="h-5 w-5" />
                  </button>
                  <button 
                    onClick={() => {
                      setActiveTab('profile');
                      setMobileMenuOpen(false);
                    }}
                    className="p-2 rounded-lg hover:bg-emerald-600/50 transition-colors"
                  >
                    <User className="h-5 w-5" />
                  </button>
                  <button
                    onClick={handleLogout}
                    className="p-2 rounded-lg hover:bg-emerald-600/50 transition-colors"
                  >
                    <LogOut className="h-5 w-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setShowAuthModal(true);
                    setMobileMenuOpen(false);
                  }}
                  className="w-full px-3 py-2 bg-white text-emerald-700 rounded-md text-base font-medium hover:bg-emerald-50 transition-colors"
                >
                  Login / Sign Up
                </button>
              )}
            </div>
          </div>
        )}
      </nav>

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
      />
    </>
  );
}