import React, { useState } from 'react';
import { Asset } from '../types';
import { Shield, Truck, AlignCenterVertical as Certificate, X, Edit, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

interface AssetCardProps {
  asset: Asset;
  onDelete?: () => void;
  isAdmin?: boolean;
}

export default function AssetCard({ asset, onDelete, isAdmin = false }: AssetCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this asset?')) return;
    
    setLoading(true);
    try {
      const { error } = await supabase
        .from('assets')
        .delete()
        .eq('id', asset.id);

      if (error) throw error;
      
      toast.success('Asset deleted successfully');
      onDelete?.();
    } catch (error: any) {
      toast.error('Error deleting asset: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
        <div className="relative">
          <img
            src={asset.images[0] || 'https://images.unsplash.com/photo-1588508065123-287b28e013da?w=800'}
            alt={asset.name}
            className="w-full h-48 object-cover"
          />
          {isAdmin && (
            <div className="absolute top-2 right-2 flex space-x-2">
              <button
                onClick={handleDelete}
                disabled={loading}
                className="p-2 bg-white/90 rounded-full hover:bg-red-100 transition-colors"
              >
                <Trash2 className="h-4 w-4 text-red-600" />
              </button>
            </div>
          )}
        </div>
        
        <div className="p-4">
          <div className="flex justify-between items-start">
            <h3 className="text-lg font-semibold">{asset.name}</h3>
            <span className="bg-emerald-100 text-emerald-800 text-xs px-2 py-1 rounded-full">
              {asset.status}
            </span>
          </div>
          <p className="text-gray-600 text-sm mt-1 line-clamp-2">{asset.description}</p>
          <div className="mt-4 flex items-center gap-4">
            <div className="flex items-center text-sm text-gray-500">
              <Shield className="h-4 w-4 mr-1" />
              <span>{asset.condition}</span>
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <Truck className="h-4 w-4 mr-1" />
              <span>{asset.location}</span>
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <Certificate className="h-4 w-4 mr-1" />
              <span>{asset.certifications.length} Certs</span>
            </div>
          </div>
          <div className="mt-4 flex justify-between items-center">
            <span className="text-lg font-bold">${asset.price.toLocaleString()}</span>
            <button 
              onClick={() => setShowDetails(true)}
              className="bg-emerald-600 text-white px-4 py-2 rounded-md hover:bg-emerald-700 transition-colors"
            >
              View Details
            </button>
          </div>
        </div>
      </div>

      {/* Details Modal */}
      {showDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="relative">
              <img
                src={asset.images[0] || 'https://images.unsplash.com/photo-1588508065123-287b28e013da?w=800'}
                alt={asset.name}
                className="w-full h-64 object-cover rounded-t-lg"
              />
              <button
                onClick={() => setShowDetails(false)}
                className="absolute top-4 right-4 bg-white p-2 rounded-full shadow-md hover:bg-gray-100 transition-colors"
              >
                <X className="h-6 w-6 text-gray-600" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-2xl font-bold text-gray-900">{asset.name}</h2>
                <span className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full text-sm font-medium">
                  {asset.status}
                </span>
              </div>

              <p className="text-gray-600 mb-6">{asset.description}</p>

              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Specifications</h3>
                  <dl className="space-y-2">
                    {Object.entries(asset.specifications).map(([key, value]) => (
                      <div key={key} className="flex justify-between">
                        <dt className="text-gray-500">{key}:</dt>
                        <dd className="font-medium">{value}</dd>
                      </div>
                    ))}
                  </dl>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-2">Details</h3>
                  <dl className="space-y-2">
                    <div className="flex justify-between">
                      <dt className="text-gray-500">Condition:</dt>
                      <dd className="font-medium">{asset.condition}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-gray-500">Location:</dt>
                      <dd className="font-medium">{asset.location}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-gray-500">Quantity:</dt>
                      <dd className="font-medium">{asset.quantity}</dd>
                    </div>
                  </dl>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Certifications</h3>
                <div className="flex flex-wrap gap-2">
                  {asset.certifications.map((cert) => (
                    <span key={cert} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                      {cert}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex justify-between items-center pt-6 border-t">
                <div>
                  <p className="text-sm text-gray-500">Price per unit</p>
                  <p className="text-3xl font-bold text-gray-900">${asset.price.toLocaleString()}</p>
                </div>
                <button className="bg-emerald-600 text-white px-6 py-3 rounded-lg hover:bg-emerald-700 transition-colors text-lg font-medium">
                  Contact Seller
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}