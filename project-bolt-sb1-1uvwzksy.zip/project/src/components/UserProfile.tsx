import React, { useEffect, useState } from 'react';
import { User, Settings, Award, BarChart2, MapPin, Globe, Mail, Edit, Save, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import AdminDashboard from './AdminDashboard';

interface ProfileData {
  id: string;
  company: string;
  type: string;
  location: string;
  rating: number;
  is_admin: boolean;
  avatar_url: string;
  bio: string;
  website: string;
  social_links: Record<string, string>;
}

interface Stats {
  [key: string]: any;
}

export default function UserProfile() {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<ProfileData>>({});
  const [email, setEmail] = useState('');

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('Not authenticated');
        return;
      }

      setEmail(user.email || '');

      // First check if user is admin
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (profileError) {
        console.error('Profile error:', profileError);
        toast.error('Error loading profile: ' + profileError.message);
        return;
      }

      if (!profileData) {
        toast.error('Profile not found');
        return;
      }

      // Set profile data
      setProfile(profileData);
      setEditForm(profileData);

      // If user is not admin, load their type-specific stats
      if (!profileData.is_admin) {
        const statsTable = profileData.type.toLowerCase() + '_stats';
        const { data: statsData, error: statsError } = await supabase
          .from(statsTable)
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (statsError && statsError.code !== 'PGRST116') {
          console.error('Stats error:', statsError);
          toast.error('Error loading stats');
        } else {
          setStats(statsData || {});
        }
      }
    } catch (error: any) {
      console.error('Load profile error:', error);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async () => {
    try {
      if (!profile) return;

      const { error } = await supabase
        .from('profiles')
        .update({
          company: editForm.company,
          location: editForm.location,
          bio: editForm.bio,
          website: editForm.website,
          social_links: editForm.social_links
        })
        .eq('id', profile.id);

      if (error) throw error;

      setProfile({ ...profile, ...editForm });
      setEditing(false);
      toast.success('Profile updated successfully');
      
      // Reload profile to get fresh data
      loadProfile();
    } catch (error: any) {
      toast.error('Error updating profile: ' + error.message);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Profile Not Found</h2>
        <p className="text-gray-600">Unable to load profile information. Please try again later.</p>
      </div>
    );
  }

  // If user is admin, show AdminDashboard
  if (profile.is_admin) {
    return <AdminDashboard />;
  }

  const renderStats = () => {
    switch (profile.type) {
      case 'Seller':
        return (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <StatCard
              icon={<BarChart2 className="h-6 w-6" />}
              title="Total Sales"
              value={`$${stats?.total_sales || 0}`}
            />
            <StatCard
              icon={<Award className="h-6 w-6" />}
              title="Average Rating"
              value={`${stats?.avg_rating || 0}/5`}
            />
            <StatCard
              icon={<Settings className="h-6 w-6" />}
              title="Active Listings"
              value={stats?.active_listings || 0}
            />
          </div>
        );
      case 'Recycler':
        return (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <StatCard
              icon={<BarChart2 className="h-6 w-6" />}
              title="Total Recycled"
              value={`${stats?.total_recycled || 0} items`}
            />
            <StatCard
              icon={<Award className="h-6 w-6" />}
              title="CO2 Saved"
              value={`${stats?.co2_saved || 0}kg`}
            />
            <StatCard
              icon={<Settings className="h-6 w-6" />}
              title="Materials Processed"
              value={`${stats?.materials_processed || 0}kg`}
            />
          </div>
        );
      case 'Refurbisher':
        return (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <StatCard
              icon={<BarChart2 className="h-6 w-6" />}
              title="Items Refurbished"
              value={stats?.items_refurbished || 0}
            />
            <StatCard
              icon={<Award className="h-6 w-6" />}
              title="Success Rate"
              value={`${stats?.success_rate || 0}%`}
            />
            <StatCard
              icon={<Settings className="h-6 w-6" />}
              title="Warranty Claims"
              value={stats?.warranty_claims || 0}
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center space-x-4">
              <div className="bg-emerald-100 p-3 rounded-full">
                <User className="h-8 w-8 text-emerald-600" />
              </div>
              {!editing ? (
                <div>
                  <h2 className="text-2xl font-bold">{profile.company}</h2>
                  <div className="flex items-center space-x-2">
                    <span className="bg-emerald-100 text-emerald-800 px-2 py-1 rounded-full text-sm">
                      {profile.type}
                    </span>
                    <span className="text-gray-500">•</span>
                    <span className="text-gray-500">{profile.location || 'No location set'}</span>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={editForm.company || ''}
                    onChange={(e) => setEditForm({ ...editForm, company: e.target.value })}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    placeholder="Company Name"
                  />
                  <input
                    type="text"
                    value={editForm.location || ''}
                    onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    placeholder="Location"
                  />
                </div>
              )}
            </div>
            {!editing ? (
              <button
                onClick={() => setEditing(true)}
                className="bg-emerald-100 text-emerald-600 p-2 rounded-full hover:bg-emerald-200"
              >
                <Edit className="h-5 w-5" />
              </button>
            ) : (
              <div className="flex space-x-2">
                <button
                  onClick={handleUpdateProfile}
                  className="bg-emerald-100 text-emerald-600 p-2 rounded-full hover:bg-emerald-200"
                >
                  <Save className="h-5 w-5" />
                </button>
                <button
                  onClick={() => {
                    setEditing(false);
                    setEditForm(profile);
                  }}
                  className="bg-red-100 text-red-600 p-2 rounded-full hover:bg-red-200"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-gray-600">
              <Mail className="h-5 w-5" />
              <span>{email}</span>
            </div>
            
            {!editing ? (
              <>
                {profile.bio && (
                  <p className="text-gray-600">{profile.bio}</p>
                )}
                {profile.website && (
                  <div className="flex items-center space-x-2">
                    <Globe className="h-5 w-5 text-gray-600" />
                    <a
                      href={profile.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-600 hover:text-emerald-500"
                    >
                      {profile.website}
                    </a>
                  </div>
                )}
              </>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Bio
                  </label>
                  <textarea
                    value={editForm.bio || ''}
                    onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                    rows={3}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    placeholder="Tell us about your company..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Website
                  </label>
                  <input
                    type="url"
                    value={editForm.website || ''}
                    onChange={(e) => setEditForm({ ...editForm, website: e.target.value })}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    placeholder="https://example.com"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-gray-200 px-6 py-4">
          <h3 className="text-lg font-semibold mb-4">Performance Stats</h3>
          {renderStats()}
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: string | number;
}

function StatCard({ icon, title, value }: StatCardProps) {
  return (
    <div className="bg-gray-50 p-4 rounded-lg">
      <div className="flex items-center">
        <div className="p-2 bg-white rounded-lg">
          {icon}
        </div>
        <div className="ml-4">
          <p className="text-sm text-gray-500">{title}</p>
          <p className="text-xl font-semibold">{value}</p>
        </div>
      </div>
    </div>
  );
}