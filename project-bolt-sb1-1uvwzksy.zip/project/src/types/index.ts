export interface Asset {
  id: string;
  name: string;
  category: 'Computers' | 'Phones' | 'Servers' | 'Networking' | 'Other';
  condition: 'New' | 'Like New' | 'Used' | 'For Parts';
  quantity: number;
  location: string;
  description: string;
  specifications: Record<string, string>;
  certifications: string[];
  price: number;
  images: string[];
  sellerId: string;
  createdAt: Date;
  status: 'Available' | 'Pending' | 'Sold' | 'In Transit';
}

export interface User {
  id: string;
  name: string;
  email: string;
  company: string;
  type: 'Seller' | 'Recycler' | 'Refurbisher';
  certifications: string[];
  location: string;
  rating: number;
}

export interface Transaction {
  id: string;
  assetId: string;
  sellerId: string;
  buyerId: string;
  price: number;
  status: 'Pending' | 'Confirmed' | 'In Transit' | 'Completed';
  trackingInfo: {
    carrier: string;
    trackingNumber: string;
    estimatedDelivery: Date;
  };
  createdAt: Date;
  updatedAt: Date;
}